<template>
  <h1 class="text-2xl font-bold text-gray-700 dark:text-gray-200 whitespace-nowrap overflow-hidden text-ellipsis drop-shadow-sm">
    e<span class="text-brand-600">c</span>ebo<span class="text-brand-600">.</span>de
  </h1>
</template>

<script>
export default {
  name: 'AppLogo'
}
</script>