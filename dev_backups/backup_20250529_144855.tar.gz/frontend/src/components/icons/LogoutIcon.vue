<template>
  <svg :class="className" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 12H8m12 0-4 4m4-4-4-4M9 4H7a3 3 0 0 0-3 3v10a3 3 0 0 0 3 3h2"></path>
  </svg>
</template>

<script>
export default {
  name: 'LogoutIcon',
  props: {
    className: {
      type: String,
      default: 'w-5 h-5'
    }
  }
}
</script>