<template>
  <div class="min-h-screen bg-gray-100 flex items-center justify-center">
    <div class="max-w-md w-full bg-white rounded-lg shadow-md p-6">
      <h1 class="text-2xl font-bold text-gray-800 mb-4">Proxmox Panel</h1>
      <p class="text-gray-600">Vue Frontend ist bereit!</p>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Home'
}
</script>