/** @type {import('tailwindcss').Config} */
export default {
  // Minimal config for Tailwind 4 - most config moved to CSS
}